<?php

/**
 * @package     Joomla.Administrator 
 * @subpackage  com_imabapi
 * 
 * @copyright   Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved. 
 * @license     GNU General Public License version 2 or later; see LICENSE.txt 
 */

// No direct access to this file

defined('_JEXEC') or die('Restricted access');

// Get an instance of the controller prefixed by com_imabapi
$controller = JControllerLegacy::getInstance('imabapi');

// Perform the Request json
$input = JFactory::getApplication()->input;
$controller->execute($input->getCmd('json'));

// Redirect if set by the controller
$controller->redirect();
