<?php
/** 
* @package     Joomla.Administrator 
* @subpackage  com_imabapi
* 
* @copyright   Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved. 
* @license     GNU General Public License version 2 or later; see LICENSE.txt 
*/ 

// No direct access to this file

defined('_JEXEC') or die('Restricted access'); 

?>

<table class="table table-striped">
<thead>
    <tr>
    	<th>Routes</th>
    	<th>JSON URI</th>
    </tr>
</thead>
<tbody>
<tr>
	<td>[/root]</td>
	<td><code><?php echo JURI::root() ; ?>index.php?option=com_imabapi</code></td>
</tr>
<tr>
	<td>[/categories]</td>
	<td><code><?php echo JURI::root() ; ?>index.php?json=categories&amp;option=com_imabapi</code></td>
</tr>
<tr>
	<td>[/content]</td>
	<td>
    <code><?php echo JURI::root() ; ?>index.php?json=content&amp;option=com_imabapi</code><br />
    <code><?php echo JURI::root() ; ?>index.php?catid=[categories_id]&amp;json=content&amp;option=com_imabapi</code>
    </td>
	
</tr>
<tr>
	<td>[/content_single]</td>
	<td><code><?php echo JURI::root() ; ?>index.php?json=content_single&amp;option=com_imabapi&amp;id=[content_id]</code></td>
</tr>
</tbody>

</table>

